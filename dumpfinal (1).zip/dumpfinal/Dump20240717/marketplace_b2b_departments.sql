CREATE DATABASE  IF NOT EXISTS `marketplace_b2b` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `marketplace_b2b`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: marketplace_b2b
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name_depart` varchar(100) DEFAULT NULL,
  `description_depart` text,
  `icon_depart` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Apparel','Discover a universe of fashion possibilities in our Apparel category. From high-quality fabrics to garment production and corporate clothing services, you will find everything you need to provide your customers with unrivalled style and functionality solutions.','ri-shirt-line'),(2,'Health & Beauty','Discover a world of well-being and elegance in our Health & Beauty category. From skincare products to health supplements, you will find everything you need to offer your customers exceptional beauty and health experiences','ri-heart-pulse-line'),(3,'Eletronics & Techonology','Explore a universe of innovation in our Electronics & Technology category. From high-quality cables and computer parts to networking services, you will find everything you need to offer your business robust, high-performance technological solutions.','ri-macbook-line'),(4,'Food & Beverages','Explore a world of culinary possibilities in our Food & Beverages category. From fresh ingredients to gourmet products, you will find everything you need to offer your customers memorable dining experiences.','ri-restaurant-line'),(5,'Interior Decor','Transform spaces with style in our Interior Decor category. From furniture for offices and commercial spaces to decorating services for offices, restaurants, shops and hotels, you will find everything you need to create impressive and functional environments.','ri-home-8-line'),(6,'Agriculture','Discover a world of agricultural solutions in our Agriculture category. From high-quality seeds and fertilisers to innovative equipment and technologies, you will find everything you need to optimise your farming operations and guarantee bumper harvests.','ri-seedling-line'),(7,'Pet Supplies','Explore a universe of care and fun in our Pet Supplies category. From nutritious pet food to livestock feed, as well as fun toys and essential accessories, you will find everything you need to ensure the well-being and happiness of all your animals.','ri-bear-smile-line'),(8,'Sports','Discover a world of activity and performance in our Sports category. From high-quality training equipment to specialised accessories, you will find everything you need to achieve your fitness goals and make the most of your business.','ri-basketball-line'),(9,'Shipping & Packaging','Explore a world of efficient logistics in our Shipping & Packaging category. From customised packaging solutions to reliable transport services, you will find everything you need to ensure that your products reach their destinations safely and professionally.','ri-box-3-line');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-17 22:45:36
